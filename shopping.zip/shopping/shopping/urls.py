"""shopping URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from django.http import HttpResponse
import logging
def logtest(request):
    # 创建日志记录器
    logger = logging.getLogger('django')
    # 输出日志
    logger.debug('测试logging模块debug')
    logger.info('测试logging模块info')
    logger.error('测试logging模块error')
    return HttpResponse('log')

urlpatterns = [
    path('admin/', admin.site.urls),
    # path('logtest/',logtest),
    # 加载users模块的urls
    path('users/',include('apps.users.urls',namespace="users")),
    # 加载contents模块的url  http://127.0.0.1:8000/
    path('',include('apps.contents.urls',namespace='contents')),
    # 加载verifications模块的url
    path('verify/',include('apps.verifications.urls',namespace='verify')),
    # 加载area模块url
    path('area/', include('apps.area.urls', namespace='area')),
    # 加载goods模块url
    path('goods/', include('apps.goods.urls', namespace='goods')),
    # 全文检索
    path('search/', include('haystack.urls')),# 加载goods模块url
    path('carts/', include('apps.carts.urls', namespace='carts')),
    # 加载订单模块的urls
    path('orders/', include('apps.orders.urls', namespace='orders')),
    path('payment/', include('apps.payment.urls', namespace='payment')),

]
