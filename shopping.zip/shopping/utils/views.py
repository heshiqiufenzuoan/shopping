# 自定义登录验证类：返回json格式的数据
from django.http import JsonResponse
from django.contrib.auth.mixins import LoginRequiredMixin


class LoginJsonRequiredMixin(LoginRequiredMixin):
    def handle_no_permission(self):
        return JsonResponse({"code":4001,"msg":"未登录"})
