REDIS_IMAGE_CODE_EXPIRE = 120 # redis缓存中图形验证码的过期时间
# 短信验证码发送信息相关配置
accId = '8a216da85bd184ce015beb06a9980946'
accToken = '845dc75faff443149ca9b8970852b1e4'
appId = '8a216da87ba59937017bc0e460f604d1'

