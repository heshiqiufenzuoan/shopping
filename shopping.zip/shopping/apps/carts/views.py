import json

from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.views import View

from apps.goods.models import SKU

"""
购物车需求分析：
    淘宝、京东：登录用户才可以操作购物车
              存储的数据：
                user_id  sku_id  count加购数量  选择状态selected
              存储方式：后台存储-》mysql、redis
              mysql：carts表-》id、*sku_id、*user_id、count、selected
              redis:数据保存原则：尽可能的少
              初步设计：redis(hash)：key:carts_2   
                               value: key  value
                                    sku_id    2
                                    count     1
                                    selected  true
              优化：redis(hash)：key:carts_2   
                               value: key  value
                                      商品id   count
                                      # 商品id   selected
                                      
                               key                value(sets)
                               selected_2         1，2，3，4 
              
    苏宁易购：登录用户可以操作购物车-同上
            未登录用户可以操作购物车
                存储数据：sku_id  count加购数量  选择状态selected
                存储方式：cookie  key/value-字符串
                    字典：{"sku_id":1,"count":2,"selected":true}
                    json字符串：json.dumps(data)
                
    加密：
        md5()：不可逆
        json字符串-》bytes-》base64(格式转化)
                    
            
    当前项目操作方式：
"""
"""
加入购物车：
    登录用户可以操作购物车 - redis
    未登录用户可以操作购物车 - cookie
    
    一、前端？后端？
        前端：ajax请求(post) 携带了参数：sku_id  count
        后端：接收数据保存购物车相关数据(redis)
    二、后端的逻辑：
        1.接收数据：sku_id  count
        2.数据校验：参数齐全、商品是否存在、加购数量是否是数值
        3.数据处理：将接受到的数据保存
        4.返回响应：json
    三、细化逻辑
        1.接收数据
            data = json.loads(request.body.decode())
            sku_id = data.get("sku_id")
            count = data.get("count")

        2.数据校验
            2.1参数是否齐全：all([])
            2.2异常处理get()
            2.3 int()
        3.数据处理
            if request.user.is_authenticated：
                # 将数据保存在redis中
                3.1连接redis
                3.2将购物车数据保存在hash中
                3.3将购物车选中状态的商品id保存在sets中
                3.4返回响应
            else:
                # 将数据保存在cookie中：cookie设置在响应中
                3.1 res = JsonResponse()
                res.set_cookie()
                3.2返回响应
    四、参数、url、post
"""
"""
展示购物车：
    一、功能需求分析：前端?后端?
        前端：展示购物车界面
        后端：提供购物车数据
    二、后端逻辑分析
        1.接受数据
        2.校验数据
        3.处理数据
        4.返回响应
    三、细化
        1.接受数据：暂无
        2.校验数据：暂无
        3.处理数据：
            判断用户的登录状态，获取购物车数据(未登录：cookie；登录用户：redis)
            if request.user.is_authenticated:
                # redis
                # 1.连接redis
                # 2.读取数据hash 、set
               
            else:
                # cookie
                # 1.读取数据
            # 根据商品的id获取商品的详细信息
            xxx
            return xxx
            
        4.返回响应
    四、get  url:carts/carts/  响应
"""
"""
编辑购物车：sku_id count selected
    一、功能需求分析，前端？后端？
        前端：ajax异步请求 put；携带参数：sku_id count selected
        后端：接受请求，编辑对应的购物车数据
        
    二、后台逻辑分析：
        1.接受数据：-》sku_id count selected
        2.数据校验：-》all()/商品是否存在/count是不是数值
        3.数据处理：
            根据用户的登录状态，修改不同存储位置的购物车数据
        4.返回响应：json
    三、细化
        1.接受数据：-》sku_id count selected
        2.数据校验：-》all()/商品是否存在/count是不是数值
        3.数据处理：
            根据用户的登录状态，修改不同存储位置的购物车数据
            未登录：修改cookie中数据
                3.1读取cookie中的数据解码成data_dict
                3.2修改字典中的对应的数据
            登录：修改redis数据：hash(count)、set(selected)
                1、hash
                2、set（选中状态的商品id）:默认架构的都是选中状态
                   取消选中状态：删除set集合中的商品id(sku_id)
                   添加某商品的选中状态：向set集合中添加该商品id
                     
        4.返回响应：json
"""
from django_redis import get_redis_connection
import pickle
import base64
class CartsView(View):
    def post(self,request):
        """购物车：新增"""
        # 1.接收数据：sku_id  count
        data = json.loads(request.body.decode())
        sku_id = data.get("sku_id")
        count = data.get("count")
        # 2.数据校验：参数齐全、商品是否存在、加购数量是否是数值
        #2.1参数是否齐全：all([])
        if not all([sku_id,count]):
            return JsonResponse({"code":400,"msg":"参数不全"})
        # 2.2异常处理get()
        try:
            skuinfo = SKU.objects.get(id=sku_id)
        except Exception as e:
            return JsonResponse({"code": 400, "msg": "商品不存在"})
        # 2.3 int()
        try:
            count = int(count)
        except Exception as e:
            count = 1

        # 3.数据处理：通过判断用户是否登录将接受到的数据保存再不同的位置
        if request.user.is_authenticated:
            # 将数据保存在redis中
            # 3.1连接redis
            redis_conn = get_redis_connection("carts")
            # 3.2将购物车数据保存在hash中
            redis_conn.hincrby("carts_%s" % request.user.id,sku_id,count)
            # 3.3将购物车选中状态的商品id保存在sets中
            redis_conn.sadd("selected_%s" % request.user.id,sku_id)
            # 3.4返回响
            return JsonResponse({"code":200,"msg":"ok"})

        else:
            # 将数据保存在cookie中：cookie设置在响应中
            # 3.1 res = JsonResponse()
            res = JsonResponse({"code":200,"msg":"ok"})
            # 组织数据:sku_id count selected
            # data = {
            #     "1":{"count":2,"selected":True},
            #     "2": {"count": 2, "selected": True}
            # }
            # bug:多次加入购物的数据只保存了最新的一条
            """
            data中保存多条购物车数据
            重复加购的商品，count+=count
            """
            # 读取cookie
            data_str = request.COOKIES.get("carts")
            if data_str is None:
                data = {}
            else:
                # 数据处理:
                data = json.loads(pickle.loads(base64.b64decode(data_str.encode())))
            # 判断加购的商品是否加购过
            if str(sku_id) in data:
                # 商品加购过：改变原来的count值
                # newcount = data[sku_id]['count'] + count
                count += data[str(sku_id)]['count']

            # 未加购：在data字典中新增一个键(sku_id)对应的值
            data[str(sku_id)] = {"count":count,"selected":True}

            # data = {
            #     sku_id:{"count":count,"selected":True}
            # }
            data_str = json.dumps(data)# 将字典转为json字符串
            data_bytes = pickle.dumps(data_str)# 将json字符串转为二进制
            data_64 = base64.b64encode(data_bytes)# 将二进制转为base64编码（二进制）
            data = data_64.decode()# 将二进制的base64编码转为字符串
            res.set_cookie("carts",data)# 字符串
            # 3.2返回响应
            return res

    def get(self,request):
        """展示购物车"""
        # 判断用户的登录状态，获取购物车数据(未登录：cookie；登录用户：redis)
        if request.user.is_authenticated:
            # 登录用户从redis中获取购物车数据
            # 1连接redis
            redis_conn = get_redis_connection("carts")
            # 2读取hash中的购物车数据
            sku_id_count = redis_conn.hgetall("carts_%s" % request.user.id)
            # print(sku_id_count)# {b'1': b'3', b'11': b'1'}
            # 3读取set中选中状态商品数据
            seleted = redis_conn.smembers("selected_%s" % request.user.id)
            # print(seleted)# {b'1', b'11'}
            # 数据格式处理：将redis中获取到的数据整理成和cookie中获取的数据格式一样的的数据
            data_dict = {}
            for sku_id,count in sku_id_count.items():
                # 判断每个商品的选中状态
                if sku_id in seleted:
                    sel = True
                else:
                    sel = False
                data_dict[sku_id.decode()] = {"count":count.decode(),"selected":sel}

        else:
            # 未登录用户从cookie中获取购物车数据
            data_str = request.COOKIES.get("carts")
            if data_str is None:
                return render(request,'cart_row.html', {"carts":[]})
            data_dict = json.loads(pickle.loads(base64.b64decode(data_str.encode())))
            """
            {
                sku_id:{count:xxx,selected:xxx},
                sku_id:{count:xxx,selected:xxx},
                sku_id:{count:xxx,selected:xxx},
            }
            """
        print(data_dict)
        ids = data_dict.keys()  # []
        # 根据商品的id获取商品的详细信息
        cartsinfo = SKU.objects.filter(id__in = ids)
        # 组织数据：模板渲染（对象）、vue渲染（json）
        carts = []
        for cart in cartsinfo:
            carts.append({
                "id":cart.id,
                "name":cart.name,
                "price":str(cart.price),
                "default_image":cart.default_image.url,
                "count": data_dict[str(cart.id)]['count'],
                "selected":str(data_dict[str(cart.id)]['selected']),
                "amount":str(int(cart.price) * int(data_dict[str(cart.id)]['count']))
            })

        # print(carts)
        context = {
            "carts":carts
        }
        """
        每个页面的建构购物车数据展示：
            响应json   
            data = {
                "code":200,
                "msg":"ok",
                "carts":carts
            }
            return JsonResponse(data)
        """
        return render(request,'cart_row.html',context)

    def put(self,request):
        # 1接收数据
        data = json.loads(request.body.decode())
        sku_id = data.get("sku_id")
        count = data.get("count")
        selected = data.get("selected",False)
        # 2数据校验
        # 2.0校验商品id是否存在
        try:
            skuinfo = SKU.objects.get(id=sku_id)
        except Exception as e:
            return JsonResponse({"code": 400, "msg": "商品不存在"})
        # 2.1参数是否齐全
        if not all([sku_id,count]):
            return JsonResponse({"code":400,"msg":"参数不全"})
        # 2.2校验count是否是数值
        try:
            count = int(count)
        except Exception as e:
            count = 1
        # 2.3校验selected是否是boolean类型
        # 3数据处理
        if request.user.is_authenticated:
            # 登录：修改redis数据库中的购物车信息
            # 1连接redis
            redis_conn = get_redis_connection("carts")
            # 2.1修改hash中的数据
            redis_conn.hset("carts_%s" % request.user.id,sku_id,count)
            # 2.2修改set中的选中数据
            if selected:
                redis_conn.sadd("selected_%s" % request.user.id,sku_id)
            else:
                redis_conn.srem("selected_%s" % request.user.id,sku_id)
            # 返回响应json
            skuinfo = {
                "id":skuinfo.id,
                "name":skuinfo.name,
                "price":str(skuinfo.price),
                "default_image":skuinfo.default_image.url,
                "count": count,
                "selected":selected,
                "amount":str(int(skuinfo.price) * count)
            }
            data = {
                "code":200,
                "msg":"ok",
                "cart_sku":skuinfo
            }
            return JsonResponse(data)

        else:
            # 未登录：修改cookie中的购物车信息
            data_str = request.COOKIES.get("carts")
            data_dict = json.loads(pickle.loads(base64.b64decode(data_str.encode())))
            data_dict[str(sku_id)] = {"count":count,"selected":selected}
            # 返回响应json
            skuinfo = {
                "id": skuinfo.id,
                "name": skuinfo.name,
                "price": str(skuinfo.price),
                "default_image": skuinfo.default_image.url,
                "count": count,
                "selected": selected,
                "amount": str(int(skuinfo.price) * count)
            }
            data = {
                "code": 200,
                "msg": "ok",
                "cart_sku": skuinfo
            }
            res = JsonResponse(data)
            # 设置新的cookie数据
            data_str = json.dumps(data_dict)  # 将字典转为json字符串
            data_bytes = pickle.dumps(data_str)  # 将json字符串转为二进制
            data_64 = base64.b64encode(data_bytes)  # 将二进制转为base64编码（二进制）
            data = data_64.decode()  # 将二进制的base64编码转为字符串
            res.set_cookie("carts",data)
            return res

    def delete(self,request):
        pass

"""
全部选择/取消选择：
    一、功能需求分析。前端？后端？
        前端：点击复选款实现购物车数据的全部选择或者全部取消
             ajax  - put -参数：selected勾选状态
        后端：接收请求实现购物车全部商品的状态的更改
    二、后端逻辑流程分析
        1.接收数据：selected：true  false
        2.校验数据：selected是不是boolean类型
        3.处理数据：根据selected参数修改购物车数据的状态
        4.返回响应：json（全部购物车商品的数据） 
    三、细化    
        1.接收数据：selected：true  false
            selected = json.loads(request.body.deocode()).get("selected",True)
        2.校验数据：selected是不是boolean类型
            if isinstance(selected,bool):
                pass
        3.处理数据：根据selected参数修改购物车数据的状态
            判断用的登录状态（登录用户）：
                selected:false->取消购物车全部数据的选中状态-》redis中seleted_userid中对应的商品id全部清空
                selected:true->将购物车全部数据的id存储在seleted_id对应的集合中 
            未登录：
                seleted:false->datadict购物车字典中selected对应的值改为false
                seleted:true->datadict购物车字典中selected对应的值改为true   
        4.返回响应：json（全部购物车商品的数据）同购物车展示的数据返回一致
    四、确认
        url:/carts/selected/
        请求方式：put 
"""
class CartsSelectedView(View):
    def put(self,request):
        # 1接受参数
        selected = json.loads(request.body.decode()).get("selected", True)
        # 2校验参数
        if not isinstance(selected,bool):
            return JsonResponse({"code":400,"msg":"参数有误"})
        # 3处理数据：修改
        if request.user.is_authenticated:
            # 登录用户修改redis中的购物车数据： carts_userid:hash {sku_id:count};seleted_userid:set
            #3.1连接redis
            redis_conn = get_redis_connection("carts")
            # 3.2获取购物车中的所有商品id
            sku_id_count = redis_conn.hgetall("carts_%s" % request.user.id)
            skuids = sku_id_count.keys()# 列表
            if selected:# 选中
                # 将购物车全部数据的商品id存储在seleted_userid对应的集合中：sadd("selected_2",skuids)
                redis_conn.sadd("selected_%s" % request.user.id,*skuids)
            else:# 取消
                # 取消购物车全部数据的选中状态-》redis中seleted_userid中对应的商品id全部清空
                redis_conn.srem("selected_%s" % request.user.id,*skuids)
            return JsonResponse({"code":"200","msg":"ok"})

        else:
            # 未登录用户修改cookie中的购物车数据
            # 3.1读取cookie中购物车的数据
            carts_str = request.COOKIES.get("carts")
            # 3.2数据校验
            if carts_str is None:
                return JsonResponse({"code":400,"msg":"暂无数据"})
            carts_dict = json.loads(pickle.loads(base64.b64decode(carts_str.encode())))
            """
            carts_dict={
                sku_id:{count:xxx,selected:xxx},
                sku_id:{count:xxx,selected:xxx}
            }
            """
            # 修改购物车数据的选中状态
            for skuid in carts_dict.keys():
                carts_dict[skuid]['selected'] = selected
            # 将修改后的数据设置到cookie中
            carts_str = base64.b64encode(pickle.dumps(json.dumps(carts_dict))).decode()
            res = JsonResponse({"code":200,"msg":"ok"})
            res.set_cookie("carts",carts_str)
            return res


"""
购物车的合并：
    一、功能需求
        购物车合并：用户登录后，将cookie中的购物车数据和redis中的购物车数据进行合并
        触发点(什么时候进行合并)？答：用户登录成功后
        将cookie中的购物车数据和redis中的购物车数据进行合并：
        eg：
        同一个用户：
            登录后的后无车数据redis：1号商品10件，3号商品1件，默认都是选中状态
                hash：{1:10,3:1}
                set：{1,3}
            未登录状态架构的商品cookie：
                carts_dict = {
                    1:{"count":2,"selected":false},
                    16:{"count":1,"selected":true}
                }
                {1:2,16:1}
                {16}
                redis_conn.hmset("key",*value={1:2,16:1})
                选中状态处理：在集合中删除某些，新添加某些
                结果：{1:2,3:1,16:1}
                     {3,16}
                
            组织新的数据存储在redis中：
                hash：{skuid:count}
                set：{skuud,skuid}
            
            去结算：-》跳转到登录页面-》登陆成功后进入购物车；购物车展示的是什么样的数据？
                redis- 1：10 true
                                    =》1：2：flase
                cookie-1：2  false 
                                       3：1：true
                                       16：1：true
            合并方案：
                以cookie中的数据为准：
                1 Redis数据库中的购物车数据保留。
                2 如果cookie中的购物车数据在Redis数据库中已存在，将cookie购物车数据覆盖Redis购物车数据。
                3 如果cookie中的购物车数据在Redis数据库中不存在，将cookie购物车数据新增到Redis。
                4 最终购物车的勾选状态以cookie购物车勾选状态为准。
            
            合并完成后，将cookie中购物车数据进行删除        
            
"""
# 合并购物车函数封装
def merge_carts(request,user,res):
    # 获取redis中的购物车数据
    redis_conn = get_redis_connection("carts")
    # 获取hash中的数据
    # sku_id_count = redis_conn.hgetall("carts_%s" % user.id)
    # 获取集合中的数据
    # selected = redis_conn.smembers("selected_%s" % user.id)
    # 获取cookie中的购物车数据
    carts_str = request.COOKIES.get("carts")
    # 判断cookie中是否存在数据,不存在则直接返回响应不进行合并操作
    if carts_str is None:
        return res

    carts_dict = json.loads(pickle.loads(base64.b64decode(carts_str.encode())))
    # 组织新的数据存储在redis中：
    # hash：{skuid:count}
    # set：{skuid,skuid}
    # 新增的购物车数据hash
    new_carts_dict = {}
    # set中的
    # 要删除选中状态的商品id
    del_ids = []
    # 要添加的选中状态的商品id
    add_ids = []
    for skuid,value in carts_dict.items():
        new_carts_dict[skuid] = value["count"]
        if value["selected"]:
            add_ids.append(skuid)
        else:
            del_ids.append(skuid)
    # 将处理好的购物车数据添加到hash中
    redis_conn.hmset("carts_%s" % user.id,new_carts_dict)
    # 将选中状态的商品id添加到set中
    if add_ids:
        redis_conn.sadd("selected_%s" % user.id,*add_ids)
    # 将取消窜中状态的商品id在set中删除
    if del_ids:
        redis_conn.srem("selected_%s" % user.id,*del_ids)
    # 删除cookie中的购物车数据
    res.delete_cookie("carts")
    return res




