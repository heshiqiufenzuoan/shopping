from django.urls import path
from .views import *
app_name = '[carts]'
urlpatterns = [
    path("carts/",CartsView.as_view(),name="carts"),
    # 全选或全部取消选择
    path("selected/", CartsSelectedView.as_view(), name="selected"),

]