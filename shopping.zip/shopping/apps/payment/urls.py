from django.urls import path
from .views import *
app_name = '[payment]'
urlpatterns = [
    # 去支付：
    path("<int:order_id>/",PayMentView.as_view(),name="pay"),
    path("status/", PayMentStatusView.as_view(), name="status")

]