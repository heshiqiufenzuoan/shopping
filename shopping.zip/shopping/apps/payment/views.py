from django.shortcuts import render

# Create your views here.
from django.views import View

from apps.orders.models import OrderInfo
from django.http import JsonResponse
"""
去支付：
    一、功能需求分析：
        前端：点击去支付ajax请求，跳转到支付宝支付界面；参数：订单编号
            /payment/order_id/
        后端：
            接受校验参数
            实现支付宝支付的第三方对接
            返回响应：json
    二、后端逻辑分析
        1.接受参数
        2.校验参数
        3.实现支付宝支付的第三方对接
        4.返回响应
    三、细化
        1.接受参数：方法中接受
        2.校验参数：
            判断订单是否存在
        3.实现支付宝支付的第三方对接
            3.1初始化支付实例对象
            alipay = AliPay(
                appid="2016090900469441",# 应用id
                app_notify_url=None,  # 默认回调 url
                app_private_key_string=app_private_key_string,
                # 支付宝的公钥，验证支付宝回传消息使用，不是你自己的公钥,
                alipay_public_key_string=alipay_public_key_string,
                sign_type="RSA2",  # RSA 或者 RSA2
                debug=True,  # 默认 False
            )
            
            3.2 实例化order_string
            subject = "测试订单"

            # 电脑网站支付，需要跳转到：https://openapi.alipay.com/gateway.do? + order_string
            # 沙箱测试：https://openapi.alipaydev.com/gateway.do
            order_string = alipay.api_alipay_trade_page_pay(
                out_trade_no="20161112",# 订单编号：trade_no:支付流水账号
                total_amount=0.01,# 总价格
                subject=subject,# 标题
                return_url="https://example.com",# 支付成功后跳转的地址
            )

            alipay_url = "https://openapi.alipaydev.com/gateway.do"+order_string
        4.返回响应：alipay_url
"""
from alipay import AliPay, DCAliPay, ISVAliPay
from alipay.utils import AliPayConfig
from utils.views import LoginJsonRequiredMixin
app_private_key_string = open("apps/payment/keys/app_private_key.pem").read()
alipay_public_key_string = open("apps/payment/keys/alipay_public_key.pem").read()

class PayMentView(LoginJsonRequiredMixin,View):
    def get(self,request,order_id):
        # 校验参数
        try:
            # 获取登陆者的未支付的某个订单
            orderinfo = OrderInfo.objects.get(order_id=order_id,user=request.user,status=1)
            # orderinfo = OrderInfo.objects.get(order_id=order_id)

        except Exception as e:
            # print(e)
            return JsonResponse({"code":400,"msg":"订单不存在"})
        # 3.1初始化支付实例对象
        alipay = AliPay(
            appid="2016090900469441",# 应用id
            app_notify_url=None,  # 默认回调 url
            app_private_key_string=app_private_key_string,
            # 支付宝的公钥，验证支付宝回传消息使用，不是你自己的公钥,
            alipay_public_key_string=alipay_public_key_string,
            sign_type="RSA2",  # RSA 或者 RSA2
            debug=True,  # 默认 False
        )
        # 3.2实例化order_string
        subject = "测试订单"

        # 电脑网站支付，需要跳转到：https://openapi.alipay.com/gateway.do? + order_string
        # 沙箱测试：https://openapi.alipaydev.com/gateway.do? + order_string
        # 正式环境：https://openapi.alipay.com/gateway.do? + order_string
        order_string = alipay.api_alipay_trade_page_pay(
            out_trade_no=order_id,  # 订单编号：trade_no:支付流水账号
            total_amount=str(orderinfo.total_amount),  # 总价格
            subject=subject,  # 标题
            return_url="http://127.0.0.1:8000/payment/status/",  # 支付成功后跳转的地址
        )
        alipay_url = "https://openapi.alipaydev.com/gateway.do?" + order_string
        return JsonResponse({"code":200,"msg":"ok","alipay_url":alipay_url})


class PayMentStatusView(View):
    def get(self,request):
        # 处理数据
        # 改变订单状态为已支付状态

        # 保存订单号和支付交易号的关系：mysql  表：id   order_id   trade_no

        # trade_no:交易号
        # 获取前端传入的请求参数
        query_dict = request.GET
        data = query_dict.dict()
        # 获取并从请求参数中剔除signature
        signature = data.pop('sign')
        # 创建支付宝支付对象
        alipay = AliPay(
            appid="2016090900469441",  # 应用id
            app_notify_url=None,  # 默认回调 url
            app_private_key_string=app_private_key_string,
            # 支付宝的公钥，验证支付宝回传消息使用，不是你自己的公钥,
            alipay_public_key_string=alipay_public_key_string,
            sign_type="RSA2",  # RSA 或者 RSA2
            debug=True,  # 默认 False
        )
        # 校验这个重定向是否是alipay重定向过来的
        success = alipay.verify(data, signature)
        if success:
            # 读取order_id
            order_id = data.get('out_trade_no')
            # 读取支付宝流水号
            trade_id = data.get('trade_no')
            # 保存Payment模型类数据
            # Payment.objects.create(
            #     order_id=order_id,
            #     trade_id=trade_id
            # )
        # 组织数据
        data= {
            "trade_id":trade_id
        }
        return render(request,'pay_success.html',data)