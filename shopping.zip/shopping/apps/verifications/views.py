import re

from django.shortcuts import render

# Create your views here.
from django.views import View
from django.http import JsonResponse
from libs.captcha.captcha import Captcha
from utils.constdata import REDIS_IMAGE_CODE_EXPIRE, accId, accToken, appId

"""
图形验证码：
一、分析功能需求：前端？后端？
    前端：展示验证码图片(scr)
    后端：生成验证码图片

二、分析大体的业务逻辑流程
    后端：1.生成验证码图片
         2.将验证码信息进行保存
         3.返回验证码图片

三、业务逻辑细化
    后端：1.生成验证码图片(captcha)
         2.将验证码信息进行保存-保存在缓存中redis
            2.1连接redis
            2.2以key-value的形式保存(有效期)
                key:用来唯一识别用户（前端、后端）
         3.返回验证码图片

四、确认请求方式/参数/响应...
    请求方式：get
    参数：key（1.url固定位置，捕获参数2.查询字符串的方式）
    url：verify/image_codes/<str:uuid>
"""
from django.http import HttpResponse
from django_redis import get_redis_connection
class ImageCodeView(View):
    def get(self,request,uuid):
        # 1.生成验证码图片(captcha)
        captcha = Captcha.instance()
        text,image = captcha.generate_captcha()
        # 2.将验证码信息进行保存 - 保存在缓存中redis
        # 2.1连接redis数据库（作业：对于第三方的一些操作要加异常处理，将异常记录在日志中）
        redis_conn = get_redis_connection("verify")
        # 2.2将验证码数据进行保存：key:value(uuid:text) 设置有效期
        # setex(name,time,value):time-以秒为单位
        # redis_conn.setex(uuid,120,text)
        redis_conn.setex("img_%s" % uuid,REDIS_IMAGE_CODE_EXPIRE,text)

        # 返回响应(image),需要制定返回的格式
        return HttpResponse(image,content_type='image/jpg')


# 发送短信验证码测试
from ronglian_sms_sdk import SmsSDK
"""
官方demo:
from ronglian_sms_sdk import SmsSDK
 
accId = '容联云通讯分配的主账号ID'
accToken = '容联云通讯分配的主账号TOKEN'
appId = '容联云通讯分配的应用ID'
 
def send_message():
    sdk = SmsSDK(accId, accToken, appId)
    tid = '容联云通讯创建的模板ID'
    mobile = '手机号1,手机号2'
    datas = ('变量1', '变量2')
    resp = sdk.sendMessage(tid, mobile, datas)
    print(resp)
"""

class SmsCodesTest(View):
    def get(self,request):
        # 发送短信验证码
        sdk = SmsSDK(accId, accToken, appId)
        tid = '1'# 测试阶段只能用1号模板【云通讯】您的验证码是{1}，请于{2}分钟内正确输入。其中{1}和{2}为短信模板参数。
        mobile = '18550141416'
        datas = ('666666', '5')
        resp = sdk.sendMessage(tid, mobile, datas)
        print(resp)
        return HttpResponse("ok")


"""
注册获取短信验证码：
一、功能需求，前端？后端？
    前端：获取短信验证码需要携带参数：手机号  图形验证码  uuid
         效果：按钮点击后开始倒计时，并且不能重复点击
         携带参数发起ajax请求发送短信验证码
    后端：
        发送短信验证码

二、分析大概的逻辑流程
    后端：
        发送短信验证码
            0.接收数据
            1.验证：
                1.0验证参数是否齐全
                1.1手机号是否合法
                2.2图形验证码是否正确
                    2.2.1连接redis
                    2.2.2获取该用户的验证码信息(通过key-uuid值获取value值)
                    2.2.3验证用户提交的提醒验证码和缓存中的验证码是否匹配
            2.发送短信验证码
                2.1随机生成六位验证码
                2.2将验证码保存在缓存中(key-mobile/value)
                2.3发送验证码
                    
三、细化逻辑

四、确认 请求方式、参数、响应...
    请求方式：get
    参数：mobile  uuid  image_code
    url: xxx/verify/sms_codes/1231231231/?uuid=xxxx&image_code=sss
    响应：json
"""
from random import randint
class SendMessageView(View):
    def get(self,request,mobile):
        redis_conn = get_redis_connection("verify")
        # 补充逻辑：有效期内不能重复发送短信验证码
        send_flag = redis_conn.get("flag_sms_%s" % mobile)
        if send_flag is not None:#判断发送短信验证码的标记是否存在：60秒内刚发了不能频繁发送
            return JsonResponse({"code":40001,"msg":"短信发送过于频繁"})

        # 1接收数据
        uuid = request.GET.get('uuid')
        image_code = request.GET.get('image_code')
        # 2.数据验证
        # 2.1验证参数是否齐全
        if not all([uuid,mobile,image_code]):
            return JsonResponse({'code':400,'msg':"参数不全"})
        # 2.2验证手机号是否合法
        # res = re.match(r'^1[3-9]\d{9}$', mobile)
        # print(res,mobile)
        if not re.match(r'^1[3-9]\d{9}$', mobile):
            return JsonResponse({'code':401,'msg':'请输入正确的手机号码'})
        # 3.验证提醒你验证码
        # 3.1连接redis
        # redis_conn = get_redis_connection("verify")
        # 3.2根据uuid获取redis中验证数据
        redis_imagecode = redis_conn.get("img_%s" % uuid)# 从redis拿到的是byets二进制
        # 3.3判断缓存中验证码信息手否存在或者过期
        if redis_imagecode is None:
            return JsonResponse({'code': 402, 'msg': '验证码不存在或者已失效'})
        # 比对:1将二进制转为字符串2.统一大小写
        if image_code.lower() != redis_imagecode.decode().lower():
            return JsonResponse({'code': 403, 'msg': '验证码输入错误'})
        # 4发送短信验证码
        # 4.1生成6位验证码
        # sms_code = randint(100000,999999)
        sms_code = "%06d" % randint(0,999999)# 001243  000034不足六位用0来补充
        # 4.2将生成的短信验证码保存到redis，并且设置发送标记位
        # redis_conn.setex("sms_%s" % mobile,120,sms_code)
        # redis_conn.setex("flag_sms_%s" % mobile,60,1)
        # 优化：使用redis的pipeline：多个命令放在同一请求中发送，返回一次响应
        # 创建redis管道
        pl = redis_conn.pipeline()
        # 将redis的多个请求命令放在队列中
        pl.setex("sms_%s" % mobile,120,sms_code)
        pl.setex("flag_sms_%s" % mobile,60,1)
        # 执行请求
        pl.execute()

        # 5.发送短信验证码
        # sdk = SmsSDK(accId, accToken, appId)
        # tid = '1'# 测试阶段只能用1号模板【云通讯】您的验证码是{1}，请于{2}分钟内正确输入。其中{1}和{2}为短信模板参数。
        mobile = mobile
        datas = (sms_code, '2')
        # resp = sdk.sendMessage(tid, mobile, datas)
        # print(resp)
        # celery异步任务:我们的函数需要通过delay调用，才能添加到broker(队列)中
        from celery_tasks.sms.tasks import send_sms_code
        # 通过delay调用
        send_sms_code.delay(mobile,datas)

        return JsonResponse({'code':200,'msg':'ok'})


"""
A：在吗？
A: 去吃饭吗？

A：在吗？去吃饭吗？


收快递：
    卖家发货或
        快递员直接放到   驿站   自己去取
        快递员----->自己手里
        
"""










