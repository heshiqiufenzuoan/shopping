from django.urls import path
from .views import *
app_name = '[verify]'
urlpatterns = [
    # 获取图形验证码
    path('image_codes/<str:uuid>/',ImageCodeView.as_view(),name="image_codes"),
    # 测试发送短信验证码
    path('sms_codes_test/',SmsCodesTest.as_view()),
    #发送短信验证码：xxx/verify/sms_codes/1231231231/?uuid=xxxx&image_code=sss
    path('sms_codes/<str:mobile>/',SendMessageView.as_view(),name="sms_codes")

]