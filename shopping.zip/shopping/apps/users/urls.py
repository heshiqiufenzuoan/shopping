from django.urls import path
from .views import *
app_name = '[users]'
urlpatterns = [
    # 注册
    path('register/',Register.as_view(),name="register"),
    # 判断用户名是否存在：xxxx:8000/users/usernames/admin11/count/
    path('usernames/<str:username>/count/',CheckUsername.as_view(),name="checkusername"),
    # 登录
    path('login/',LoginView.as_view(),name="login"),
    # 退出登录
    path('logout/', LogoutView.as_view(), name="logout"),
    # 用户中心
    path('center/', UserCenterView.as_view(), name="center"),
    # 新增邮箱信息 /users/emails/
    path('emails/', AddEmail.as_view(), name="emails"),
    # 邮箱激活
    path("email_active/",EmailActive.as_view(),name="email_active"),
    # 收货地址
    path("address/", AddressView.as_view(), name="address"),
    # 编辑收货地址
    path('address/<int:address_id>/', AddrUdateView.as_view(), name="addrupdate")

]