# 实现多账号登录：默认是根据账号username字段去登录
from django.contrib.auth.backends import ModelBackend
# username/mobile
from django.db.models import Q

from apps.users.models import User
import re

# 封装的思想(剥离功能)：降低耦合度(高内聚低耦合)、提高重用性
from shopping.settings import SECRET_KEY


def GetUser(username):
    # try:
    #     if re.match(r"^1[3-9]\d{9}$", username):
    #         # print(1)
    #         user = User.objects.get(mobile=username)
    #     else:
    #         # print(2)
    #         user = User.objects.get(username=username)
    # except user.DoesNotExist:
    #     return None
    try:
        user = User.objects.get(Q(username=username) | Q(mobile=username))
    except Exception as e:
        return None

    return user


class UsernameMobileBackend(ModelBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        # 根据用户提交的username信息判断是手机号还是账号或者邮箱号
        # try:
        #     if re.match(r"^1[3-9]\d{9}$",username):
        #         # print(1)
        #         user = User.objects.get(mobile=username)
        #     else:
        #         # print(2)
        #         user = User.objects.get(username=username)
        # except user.DoesNotExist:
        #     return None
        user = GetUser(username)
        # 找到用户对象后验证密码是否正确并验证用户的活跃状态
        if user.check_password(password) and self.user_can_authenticate(user):
            return user

    def user_can_authenticate(self, user):
        """
        Reject users with is_active=False. Custom user models that don't have
        that attribute are allowed.
        """
        is_active = getattr(user, 'is_active', None)
        return is_active or is_active is None

# 生成加密的邮箱验证url:itsdangerous
import itsdangerous
def get_email_active_url(user_id):
    # 设置加密解密秘钥（暗号）
    secret_key = SECRET_KEY
    s = itsdangerous.TimedJSONWebSignatureSerializer(secret_key=secret_key,expires_in=600)
    data = {
        "user_id":user_id
    }
    res = s.dumps(data)# 二进制
    token = res.decode()

    return "http://127.0.0.1:8000/users/email_active/?token=%s" % token

# 解密
def deciphering(token):
    secret_key = SECRET_KEY
    s = itsdangerous.TimedJSONWebSignatureSerializer(secret_key=secret_key, expires_in=600)
    try:
        res = s.loads(token)
    except Exception as e:
        return None
    user_id = res.get("user_id")
    user = User.objects.get(id = user_id)
    return user







