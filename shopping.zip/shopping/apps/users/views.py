import json
import re
from django.contrib.auth.backends import ModelBackend
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse

from apps.users.models import User
from django.shortcuts import render, redirect
from django.views import View
from django.http import HttpResponse,HttpResponseBadRequest,HttpResponseForbidden,JsonResponse
# Create your views here.
import logging
from django_redis import get_redis_connection
# 注册
from apps.users.utils import get_email_active_url, deciphering
from celery_tasks.email.tasks import send_email_message
from shopping.settings import EMAIL_FROM
from .models import *

class Register(View):
    def get(self,request):
        """
        get方式展示注册界面
        """
        return render(request,'register.html')
    def post(self,request):
        # 1.接受数据:username/password/password2/mobile/
        data = request.POST
        username = data.get("username")# 如果获取不到返回None
        password = data.get("password")
        password2 = data.get("password2")
        mobile = data.get("mobile")
        sms_code_client = request.POST.get('sms_code')
        allow = request.POST.get("allow")
        # 2.对数据的合法性进行二次校验
        """
        数据合法性校验：
            1.每个数据不为空
            2.每个数据的合法性username:5~20;password:8~20;password == password2;mobile
        """
        # 判断列表中的每个参数是否齐全
        if not all([username,password2,password,mobile]):
            return HttpResponseBadRequest("参数不完整")
        # 判断用户名是否是5-20个字符
        if not re.match(r'^[a-zA-Z0-9_-]{5,20}$', username):
            return HttpResponseForbidden('请输入5-20个字符的用户名')
        # 判断密码是否是8-20个数字
        if not re.match(r'^[0-9A-Za-z]{8,20}$', password):
            return HttpResponseForbidden('请输入8-20位的密码')
        # 判断两次密码是否一致
        if password != password2:
            return HttpResponseForbidden('两次输入的密码不一致')
        # 判断手机号是否合法
        if not re.match(r'^1[3-9]\d{9}$', mobile):
            return HttpResponseForbidden('请输入正确的手机号码')
        # 判断是否勾选用户协议
        if allow != 'on':
            return HttpResponseForbidden('请勾选用户协议')
        # 添加短信验证码输入是否正确
        redis_conn = get_redis_connection("verify")
        sms_code_server = redis_conn.get('sms_%s' % mobile)
        if sms_code_server is None:
            return render(request, 'register.html', {'sms_code_errmsg': '无效的短信验证码'})
        if sms_code_client != sms_code_server.decode():  # redis返回byets
            return render(request, 'register.html', {'sms_code_errmsg': '输入短信验证码有误'})

        # 3.存入数据库（逻辑严谨添加异常处理）
        try:
            user = User.objects.create_user(username=username,password=password,mobile=mobile)
        except Exception as e:
            # 添加日志
            # 创建日志记录器
            logger = logging.getLogger("django")
            logger.error(e)
            # 返回错误信息
            return HttpResponseForbidden("数据库错误")
        # 方法二：
        # user = User()
        # user.username = username
        # user.set_password(password)
        # user.mobile = mobile
        # user.save()

        # 注册成功：1注册完成跳转到登录界面*2注册完成无需登录操作直接进入到index(状态保持)
        # 自己完成session数据存储 request.session
        # 调用内部login()方法：自动将用户信息保存在session中
        login(request,user)

        return redirect(reverse("contents:index"))

"""
一、分析功能:前端需要做什么？后端需要做什么
    前端：失去焦点发起异步请求验证用户名是否重复，显示对应的提示
    后端：验证用户名是否重复
二、分析功能的大概的逻辑流程
    后端：1.接受获取数据
         2.根据接收到的数据去数据库验证数据是否唯一
         3.根据结果返回响应的内容
         
    前端：1.绑定鼠标失去焦点的事件，调用方法
         2.定义一个方法，发起一个ajax异步请求-get
         3.根据请求返回的结果判断用户名的有效性
         4.根据判断结果显示提示信息
三、根据大概的逻辑分析细化
    后端：1.接受获取数据（从方法中的参数获取）username = 'admin'
         2.根据接收到的数据去数据库验证数据是否唯一（）
            count = User.objects.filter(username='admin').count()# number:0,1
            exists()
         3.根据结果返回响应的内容
            json:{'code':200,'msg':'yes','count':count}
四、确认请求方式/参数/响应...
    1.请求方式：get 
    2.参数：url固定的位置捕获参数 'xxx/<str:xxx>'  ==> def test(request,xxxx)
    3.JsonReponse() json:{'code':200,'msg':'yes','count':count}
"""
class CheckUsername(View):
    def get(self,request,username):
        # 1.接收数据
        # 2.根据接收到的数据去数据库验证数据是否唯一
        count = User.objects.filter(username=username).count()
        # 3.返回响应
        return JsonResponse({'code':200,'msg':'ok','count':count})


# 登录
"""
一、功能需求，前端？后端？
    前端：需要提供参数：用户名、密码、【记住密码】
    后端：1.接收参数
         2.参数校验(二次校验)
            2.1参数齐全
            2.2用户名：5-20
            2.3密码：8-20
         3.验证用户名和密码是否正确
         4.响应结果

二、分析大概的逻辑(后台)
    后端：1.接收参数
         2.参数校验(二次校验)
            2.1参数齐全
            2.2用户名：5-20
            2.3密码：8-20
         3.验证用户名和密码是否正确
         4.响应结果：状态保持 跳转首页
三、细化逻辑
    记住密码：状态保持的有效期设置
四、确认请求方式、参数、url、响应
    请求方式：get(展示登录页面)  post(提交登录请求)
    url:ip:port/users/login/
    响应：get-login.html页面
         post：跳转到首页
"""
class LoginView(View):
    def get(self,request):
        # 展示登录界面
        return render(request,"login.html")

    def post(self,request):
        """
        1.接收参数
         2.参数校验(二次校验)
            2.1参数齐全
            2.2用户名：5-20
            2.3密码：8-20
         3.验证用户名和密码是否正确
         4.响应结果：状态保持 跳转首页
        """
        # 1接收参数
        data = request.POST
        # print(data)
        username = data.get("username")
        password = data.get("password")
        remembered = data.get("remembered")# 没有勾选记住密码data中没有remembered键，返回None
        # 2参数校验
        if not all([username,password]):
            return render(request,'login.html',{"code":400,"msg":"参数不全"})
        # 2.1判断用户名是否是5-20个字符
        if not re.match(r'^[a-zA-Z0-9_-]{5,20}$', username):
            return HttpResponseForbidden('请输入5-20个字符的用户名')
        # 2.2判断密码是否是8-20个数字
        if not re.match(r'^[0-9A-Za-z]{8,20}$', password):
            return HttpResponseForbidden('请输入8-20位的密码')
        # 3验证用户名和密码是否正确
        # 3.1方法1：根据用户名去获取用户对象，然后检验密码是否正确：check_password()
        # user = User.objects.get(username=username)
        # if user.check_password(password):
        #     pass
        # 3.1方法一：使用内部提供的认证方式authenticate():匹配成功返回user对象，不成功None
        user = authenticate(username=username,password=password)# 注意参数传递方式
        if user is None:
            return render(request, 'login.html', {"code": 400, "msg": "用户名密码不匹配"})
        # 4状态保持
        login(request,user)# 默认有效期14天

        # 5记住密码功能：默认没有勾选记住密关闭浏览器结束会话则过期、延长有效期
        if remembered is None:# 没有选
            # 如果value为0，那么用户session的Cookie将在用户的浏览器关闭时过期。
            request.session.set_expiry(0)
        else:
            request.session.set_expiry(3600*24*7)# 记住密码七天有效期

        # 6成功返回响应
        # 新增功能：没有登录时访问的url跳转的登录界面，登陆成功后直接跳转到之前想要访问的界面
        # LoginRequiredMixin,跳转到登录界面时url中会有next参数
        next = request.GET.get("next")
        if next is None:
            res =  redirect("contents:index")
        else:
            res = redirect(next)
        # 为了前端能从cookie中获取登录用户名，需要将username保存在cookie中
        # res.set_cookie(key,value,max_age)
        res.set_cookie("username",user.username)
        # new:-----合并购物车数据（封装成一个函数）
        from apps.carts.views import merge_carts
        res= merge_carts(request,user,res)
        return res

# 退出登录
class LogoutView(View):
    def get(self,request):
        # 清空session信息
        # request.session.flush()
        # 框架内部提供logout()
        logout(request)
        # 清空cookie中的username数据
        res = redirect(reverse("users:login"))
        res.delete_cookie("username")
        return res

# 用户中心
class UserCenterView1(View):
    def get(self,request):
        # 判断用户手否登录；登录显示用户中心页面，未登录跳转到登录界面
        if request.user.is_authenticated:
            return render(request,'user_center_info.html')
        else:
            return redirect(reverse("users:login"))

# LoginRequiredMixin的使用需要配置LOGIN_URL = '登录地址'；next
class UserCenterView(LoginRequiredMixin,View):
    def get(self,request):
        return render(request, 'user_center_info.html')

# 邮箱账号完善
"""
一、前端？后端？
    前端：验证邮箱的格式，发起ajax异步请求
    后端：1.接受数据
         2.二次校验数据的合法性
         3.将用户提交的数据保存到数据库
         4.返回响应信息
二、细化
    后端：1.接受数据
         2.二次校验数据的合法性
         3.将用户提交的数据保存到数据库（未激活）
            3.1给该邮箱发送一封邮件
            3.2点击邮件中的连接进行激活操作，激活完成（已激活）
            （user：邮箱的激活状态）
         4.返回响应信息
三、确认请求方式、参数、响应
    请求方式：post、get、put/patch、delete========修改：put
"""
class AddEmail(View):
    def put(self,request):
        # 1接受参数(ajax异步请求，提交的json数据的接受)
        data_byets = request.body
        data_str = data_byets.decode() #json字符串：'{"email":"xxxx"}'
        # 将json字符串转为程序可以处理的数据格式
        data = json.loads(data_str)# 字典
        email = data.get("email")# None
        # 2数据校验
        if email is None:
            return JsonResponse({'code': 400, 'msg': '参数不齐全'})
        if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$',email):
            return JsonResponse({'code':400,'msg':'参数有误'})
        # 3将邮箱数据保存到数据库中
        try:
            request.user.email = email
            request.user.save()
        except Exception as e:
            # 添加日志。。。。
            return JsonResponse({'code':400,'msg':'数据库错误'})
        # 3.1发送邮件进行激活
        from django.core.mail import send_mail
        """
        send_mail(subject, message, from_email, recipient_list,
                   html_message=None)
        subject:邮件主题、标题
        message：邮件内容（文本内容）
        from_email：发件人
        recipient_list：收件人列表
        html_message：带有格式的邮件内容
        """
        # subject = "某某商城邮件激活"
        # message = "test"
        # # from_email = "601228137@qq.com"
        # recipient_list = ["601228137@qq.com"]
        # send_mail(subject=subject,message=message,from_email=EMAIL_FROM,recipient_list=recipient_list)
        # 优化：使用celery实现异步发送邮件
        from celery_tasks.email.tasks import send_email_message
        url = get_email_active_url(request.user.id)
        send_email_message.delay(email,url)

        # 4返回响应
        return JsonResponse({'code':200,'msg':'ok'})

"""
激活邮箱的连接设计：
激活逻辑：
    1.用户收到了激活邮件，点击链接进行激活
    2.链接：Http://XXXX:XXX/email_active/?userid=33&email=xxxx
        url中的数据进行加密操作：itsdangerous
        Http://XXXX:XXX/users/email_active/?token=ashdiasdhfuaidfaisdbfa
        获取到具体是哪一个用户
        激活（数据库中某一条数据的email_active=True）
后台大概逻辑：
    1.接受参数
    2.参数校验
    3.解密从token令牌中获取用户信息
    4.修改具体某个用户的邮箱激活状态
    5.返回响应
确认：
    请求方式：get
    url：Http://XXXX:XXX/users/email_active/?token=ashdiasdhfuaidfaisdbfa
        path("email_active/",EmailActive.as_view(),name="email_active")
    响应：如果错误信息或者成功激活后跳转到个人中心    
"""

class EmailActive(View):
    def get(self,request):
        # 1.接受参数
        token = request.GET.get("token")
        # 2.参数校验
        if token is None:
            return HttpResponseForbidden("参数错误")

        # 3.解密从token令牌中获取用户信息
        user = deciphering(token)
        if user is None:
            return HttpResponseForbidden("参数错误")

        # 4.修改具体某个用户的邮箱激活状态
        user.email_active = True
        user.save()
        # 5.返回响应
        return redirect(reverse("users:center"))

# 展示收货地址页面
class AddressView(View):
    def get(self,request):
        # 获取当前用户的所有收货地址数据
        addresses=  Address.objects.filter(user_id = request.user.id,is_deleted=False)# queryset
        # [{id,。。。},{}]
        data = []
        for address in addresses:
            data.append({
                "id": address.id,
                "title": address.title,
                "receiver": address.receiver,
                "province": address.province.name,
                "province_id":address.province.id,
                "city": address.city.name,
                "city_id":address.city.id,
                "district": address.district.name,
                "district_id":address.district.id,
                "place": address.place,
                "mobile": address.mobile,
                "tel": address.tel,
                "email": address.email
            })

        return render(request,'user_center_site.html',context={"data":data})

    def post(self,request):
        # 1.接受数据
        # data_bytes = request.body
        # data_str = data_bytes.decode()
        # data = json.loads(data_str)
        # 接收参数
        json_dict = json.loads(request.body.decode())
        receiver = json_dict.get('receiver')
        province_id = json_dict.get('province_id')
        city_id = json_dict.get('city_id')
        district_id = json_dict.get('district_id')
        place = json_dict.get('place')
        mobile = json_dict.get('mobile')
        tel = json_dict.get('tel')
        email = json_dict.get('email')
        # 2.校验数据
        # 校验参数
        if not all([receiver, province_id, city_id, district_id, place, mobile]):
            return HttpResponseForbidden('缺少必传参数')
        if not re.match(r'^1[3-9]\d{9}$', mobile):
            return HttpResponseForbidden('参数mobile有误')
        if tel:
            if not re.match(r'^(0[0-9]{2,3}-)?([2-9][0-9]{6,7})+(-[0-9]{1,4})?$', tel):
                return HttpResponseForbidden('参数tel有误')
        if email:
            if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):
                return HttpResponseForbidden('参数email有误')
        # 3.存储数据
        address = Address.objects.create(
            user=request.user,
            title=receiver,
            receiver=receiver,
            province_id=province_id,
            city_id=city_id,
            district_id=district_id,
            place=place,
            mobile=mobile,
            tel=tel,
            email=email
        )
        # address = Address()
        # address.user = request.user
        # address.title = receiver
        # ...
        # address.save()
        # 补充：判断当前用户有没有默认地址，如果没有则把新增的地址作为该用户的默认地址
        res = request.user.default_address# None
        if res is None:
            # 把新增的地址作为该用户的默认地址
            request.user.default_address = address
            # request.user.default_address_id = address.id
            request.user.save()

        # 4.返回响应
        # 新增地址成功，将新增的地址响应给前端实现局部刷新
        address_dict = {
            "id": address.id,
            "title": address.title,
            "receiver": address.receiver,
            "province": address.province.name,
            "city": address.city.name,
            "district": address.district.name,
            "place": address.place,
            "mobile": address.mobile,
            "tel": address.tel,
            "email": address.email
        }
        data = {
            "code":200,
            "msg":"ok",
            "address":address_dict

        }
        return JsonResponse(data)



"""
开发前的分析套路：
一、功能需求分析：前端？后端
二、分析大概的业务逻辑(后台)
三、细化逻辑
四、确认：url、参数、请方式、响应。。。
"""
"""
新增收货地址：
一、功能需求分析：前端？后端
    前端：点击新增收货地址弹框
         点模态框中新增-》数据校验-》发起ajax请求(json)
    后端： 
        1.接受数据
        2.校验数据
        3.存储数据
        4.返回响应
        
二、分析大概的业务逻辑(后台)
        1.接受数据-》request.body->decode()->json.loads()
        2.校验数据-》参数是否完整-》手机号。固定电话。邮箱地址的合法性
        3.存储数据-》Address.objects.create()   .save()
        4.返回响应-》json(code/msg)、为了实现局部刷新的效果，需要返回新增成功的所有数据

三、细化逻辑

四、确认：url、参数、请方式、响应。。。
    url：/users/address
    参数：存储所需要的所有必填数据
    请求方式：post
    响应：json(code/msg/新增成功的数据)
"""
"""
编辑收货地址：
开发前的分析套路：
一、功能需求分析：前端？后端？
    前端：点击编辑按钮显示包含当前信息的模态框，编辑信息，点击修改按钮提交编辑数据（ajax-put）
    后端：接收前端请求进行数据的修改
    
二、分析大概的业务逻辑(后台)
    1.接收数据
    2.数据校验
    3.数据修改
    4.返回响应
    
三、细化逻辑
    1.接收数据-》data=json.loads(request.body.decode())
    2.数据校验-》和新增一样
    3.数据修改-》update  .save()
    4.返回响应-》json（code,msg,address）
四、确认：url、参数、请方式、响应。。。
    参数：url固定位置捕获参数：address_id   查询字符串的方式: ?address_id=xxx
         修改的地址信息数据（body）
    url：path('address/<int:address_id>/',AddrUdateView.as_view(),name="addrupdate")
         path('addrupdate/',AddrUdateView.as_view(),name="addrupdate")
        
    请求方式：put
    
"""

"""
删除收货地址：
一：
    前端：点击删除发起ajax请求
    后端：接收请求，删除数据
二、三：
    1.接收数据-》address_id
    2.数据校验-》校验当前id对应的数据是否存在
    3.删除数据-》Address.objects.filter(id=address_id).delete()  !!!!
    4.返回响应-》json（code,msg）
四：
    参数
    url
    请求方式：delete
"""
logger = logging.getLogger("django")

class AddrUdateView(View):
    def put(self,request,address_id):
        # 1.接收数据 -》data = json.loads(request.body.decode())
        json_dict = json.loads(request.body.decode())
        receiver = json_dict.get('receiver')
        province_id = json_dict.get('province_id')
        city_id = json_dict.get('city_id')
        district_id = json_dict.get('district_id')
        place = json_dict.get('place')
        mobile = json_dict.get('mobile')
        tel = json_dict.get('tel')
        email = json_dict.get('email')
        # 2.数据校验-》和新增一样
        # 校验参数
        if not all([receiver, province_id, city_id, district_id, place, mobile]):
            return HttpResponseForbidden('缺少必传参数')
        if not re.match(r'^1[3-9]\d{9}$', mobile):
            return JsonResponse({"code":4001,"msg":"参数mobile有误"})
            # return HttpResponseForbidden('参数mobile有误')
        if tel:
            if not re.match(r'^(0[0-9]{2,3}-)?([2-9][0-9]{6,7})+(-[0-9]{1,4})?$', tel):
                return JsonResponse({"code": 4002, "msg": "参数tel有误"})
                # return HttpResponseForbidden('参数tel有误')
        if email:
            if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):
                return JsonResponse({"code": 4003, "msg": "参数email有误"})

                # return HttpResponseForbidden('参数email有误')

        # 3.数据修改-》update  .save()

        try:# 编辑返回影响条数
            # 判断要修改的数据是否存在
            address = Address.objects.get(id=address_id)  # 需要添加异常处理
            address_count = Address.objects.filter(id=address_id).update(
                title=receiver,
                receiver=receiver,
                province_id=province_id,
                city_id=city_id,
                district_id=district_id,
                place=place,
                mobile=mobile,
                tel=tel,
                email=email
            )
        except Exception as e:
            # 添加日志
            logger.error(e)
            return JsonResponse({"code:":400,"msg":"数据库错误"})
        # 4.返回响应-》json（code,msg,address）
        # 构建组织响应数据-
        address = Address.objects.get(id=address_id)
        address_dict = {
            "id": address.id,
            "title": address.title,
            "receiver": address.receiver,
            "province": address.province.name,
            "city": address.city.name,
            "district": address.district.name,
            "place": address.place,
            "mobile": address.mobile,
            "tel": address.tel,
            "email": address.email
        }
        return JsonResponse({"code":200,"msg":"ok","address":address_dict})

    def delete(self,request,address_id):
        """删除地址"""
        try:
           address = Address.objects.get(id=address_id)
           # address.delete()# 物理删除
           # is_deleted 逻辑删除
           address.is_deleted = True
           address.save()

        except Exception as e:
            logger.error(e)
            return JsonResponse({"code":400,"msg":"数据库错误"})

        return JsonResponse({"code":200,"msg":"ok"})




