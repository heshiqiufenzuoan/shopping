from django.urls import path
from .views import *
app_name = '[contents]'
urlpatterns = [
    # 首页
    path('',IndexView.as_view(),name="index")
]