from django.shortcuts import render
from django.views import  View
# Create your views here.
from apps.contents.models import ContentCategory
from apps.contents.utils import get_categories


class IndexView(View):
    """首页广告"""

    def get(self, request):
        """提供首页广告界面"""
        # 查询商品频道和分类
        categories = get_categories()

        # 广告数据
        contents = {}
        content_categories = ContentCategory.objects.all()
        for cat in content_categories:
            contents[cat.key] = cat.content_set.filter(status=True).order_by('sequence')

        # 渲染模板的上下文
        context = {
            'categories': categories,
            'contents': contents,
        }
        return render(request, 'index.html', context)


"""
数据关系：
1.一对一：两张表
    eg: 用户信息
        编号  姓名  年龄  性别 身份证号  电话号 邮箱号 ||  （家庭住址  老家地址  个人简介  民族）
        
        用户基本信息表：
        编号  姓名  年龄  性别 身份证号  电话号 邮箱号   详情编号
         1    zs    18   女   xxx    xxx   xxxx      2
         
        用户详情表：(存放用户不常用的数据详情)
        编号  家庭住址  老家地址  个人简介  民族
         .......
         2     xxxx     xxxx    xxxx    xxx

2.一对多：两张表-外键定义在多的一方
    eg:  班级---学生(class_id)
         书籍----人物

3.多对多：三张表
    eg：学生----老师
    学生表：
    编号  姓名  电话  年龄 ....
     1    zs   19...  xxx
     2    ls   18...  xxx
    
    老师表：
    编号   姓名     电话  年龄....职称
     1    张老师   19...  xxx
     2    李老师   13...  xxx
    
    关系表：
    编号   老师id   学生id
     1       1      1
     2       1      2
     3       2      1
     4       2      2
     
     eg：供应商 --- 商品

    
"""

"""
首页广告：一对多两张表
    广告类型     广告内容（外键广告类型）
    轮播图        1，2，3，4
    快讯广告      连接广告内容
    楼层广告      。。。。
                
"""