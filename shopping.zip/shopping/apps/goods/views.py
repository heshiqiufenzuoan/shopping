import json

from django.core.paginator import Paginator
from django.shortcuts import render, redirect

# Create your views here.
from django.urls import reverse
from django.views import View
from django.http import HttpResponse, HttpResponseForbidden, JsonResponse
from apps.goods.models import SKU, GoodsCategory
from apps.goods.utils import get_bread
from utils.views import LoginJsonRequiredMixin

"""
一、
二、
    后端：获取某一个商品分类下的所有商品数据
         自定义排序
         商品列表分页展示
         商品分类数据
         热销推荐商品数据
         
         面包屑：
            分类的导航菜单
                如果点击的是1级分类：只有一集分类： eg：手机
                如果点击的是2级分类：2集分类： eg：手机/智能设备
                如果点击的是3级分类：3集分类： eg：手机/智能设备/智能手环
                
            category_id：
                需要判断当前是第几级分类？
                    breadcrumb = {
                        'cat1':cat1,
                        'cat2':cat2,
                        'cat3':cat3,
                    }
                    当前分类信息：category = GoodsCategory.objects.get(id=category_id)
                    判断方法：没有上级编号则属于一级分类
                                breadcrumb['cat1'] = category
                            判断当前分类是否存在下一级，存在则为二级分类
                                breadcrumb['cat1'] = category.parent
                                breadcrumb['cat2'] = category
                            否则为三级分类
                                breadcrumb['cat1'] = category.parent.parent
                                breadcrumb['cat2'] = category.parent
                                breadcrumb['cat3'] = category
                            
            

细化：
    1.获取某一个商品分类下的所有商品数据
"""
# 商品列表
class GoodsListView(View):
    def get(self,request,category_id,page):
        # 获取面包屑数据
        try:
            category = GoodsCategory.objects.get(id=category_id)
        except Exception as e:
            return HttpResponseForbidden("分类数据有误")

        breadcrumb = get_bread(category)
        # 接受排序参数
        sort = request.GET.get("sort","default")
        if sort == "price":
            order_field = "price"
        elif sort == "hot":
            order_field = "sales"
        else:
            order_field = "create_time"
        # 获取某一个商品分类下的所有商品数据,根据需求排序
        goods_sku = SKU.objects.filter(category_id=category_id).order_by(order_field)
        # 分页展示
        # 1.创建分页实例
        pagnation = Paginator(goods_sku,5)
        # 2.获取指定页码的数据
        try:
            goods_page = pagnation.page(page)
        except Exception as e:
            goods_page = pagnation.page(1)
        # 3.获取分页数据
        total_page = pagnation.num_pages

        # 组织数据
        context = {
            "goods":goods_page,# 将用户想要看的指定页码的数据传给模板
            "category_id":category_id,
            "sort":sort,
            "current_page":page,# 当前页
            "total_page":total_page,# 总页数
            "breadcrumb":breadcrumb
        }
        return render(request,'list.html',context=context)


"""
一、
    前端：页面加载完成后发起ajax请求获取热销产品
    后端：接受请求，返回某个分类下的热销产品

二、后端逻辑流程：
    1.接受数据 category_id
    2.数据校验 验证是否存在当前分类
    3.获取当前分类的热销数据
    4.返回响应
    
三、逻辑细化
    1.接受数据 category_id=》url固定位置捕获参数（def get(xxx,category_id)）
    2.数据校验 验证是否存在当前分类-》 get方法的异常处理
    3.获取当前分类的3条热销数据-》  销量排名前三 （根据salse倒叙排序，拿三条-切片操作）
    4.返回响应-json数据（code,msg,hot_sku）
    
四、确认
    url: goods/hot/123/
    请求方式：get
    参数：category_id
    响应：
"""
# 获取某个分类下的热销产品
class GoodsHotView(View):
    def get(self,request,category_id):
        # 数据校验：分类编号是否存在
        try:
            category = GoodsCategory.objects.get(id=category_id)
        except Exception as e:
            return JsonResponse({"code":400,"msg":"数据错误"})
        # 获取当前分类下的三条上架状态的热销数据
        hot_sku = SKU.objects.filter(category=category,is_launched=True).order_by("-sales")[:3]
        # 组织数据返回响应
        hot_list = []
        for sku in hot_sku:
            hot_list.append({
                "id":sku.id,
                "name":sku.name,
                "default_image":sku.default_image.url,
                "price": sku.price
            })
        data = {
            "code":200,
            "msg":"ok",
            "hot_list":hot_list,

        }
        return JsonResponse(data)

"""
全文搜索（检索）-商品：
    后台思路：
        keywords
        模糊查询：sql-》like
        select * from sku where name like '%xxxx%' or .....;
        SKU.objects.filter(name__contains=keywords)多个字段查询条件or的关系用到Q方法
    模糊查询like：查询速度比较低
"""
"""
商品的详情：
    一、前端？后端？
        前端：sku_id
        后端：根据id获取商品的相关信息
    二、后端大致的逻辑流程
        1.接受数据
        2.校验数据
        3.数据处理(增删改查)
        4.返回响应
    三、细化
        1.接受数据：sku_id
        2.校验数据：校验sku_id是否存在
        3.数据处理(增删改查)
            -》获取id对应的商品相关数据(详细的描述信息)
              分类数据、面包屑、热销数据(ajax)、评论(ajax)
        4.返回响应
            普通的get方式请求，渲染页面，传递参数
    四、确认
        url:/goods/detail/122/
"""
from apps.contents.utils import get_categories
from .utils import get_bread
class GoodsDetailView(View):
    """商品详情页"""

    def get(self, request, sku_id):
        """提供商品详情页"""
        # 获取当前sku的信息
        try:
            sku = SKU.objects.get(id=sku_id)
        except SKU.DoesNotExist:
            return redirect(reverse("contents:index"))

        # 查询商品频道分类
        categories = get_categories()
        # 查询面包屑导航
        breadcrumb = get_bread(sku.category)

        # 构建当前商品的规格键
        sku_specs = sku.specs.order_by('spec_id')
        sku_key = []
        for spec in sku_specs:
            sku_key.append(spec.option.id)
        # 获取当前商品的所有SKU
        skus = sku.spu.sku_set.all()
        # 构建不同规格参数（选项）的sku字典
        spec_sku_map = {}
        for s in skus:
            # 获取sku的规格参数
            s_specs = s.specs.order_by('spec_id')
            # 用于形成规格参数-sku字典的键
            key = []
            for spec in s_specs:
                key.append(spec.option.id)
            # 向规格参数-sku字典添加记录
            spec_sku_map[tuple(key)] = s.id
        # 获取当前商品的规格信息
        goods_specs = sku.spu.specs.order_by('id')
        # 若当前sku的规格信息不完整，则不再继续
        if len(sku_key) < len(goods_specs):
            return
        for index, spec in enumerate(goods_specs):
            # 复制当前sku的规格键
            key = sku_key[:]
            # 该规格的选项
            spec_options = spec.options.all()
            for option in spec_options:
                # 在规格参数sku字典中查找符合当前规格的sku
                key[index] = option.id
                option.sku_id = spec_sku_map.get(tuple(key))
            spec.spec_options = spec_options

        # 渲染页面
        context = {
            'categories': categories,
            'breadcrumb': breadcrumb,
            'sku': sku,
            'specs': goods_specs,
        }
        return render(request, 'detail_sku.html', context)

"""
用户浏览记录：
    用户查看过详情的商品
        查看详情的同时，将用户的浏览记录保存下来
        
    后端：
        将浏览记录保存下来（mysql/redis）
        保存方式：redis：list=》key、list  => history_user_id:[2,3,4,5]
        存储的内容：商品id  用户id
        数据：数据不能重复:新增数据时先判断当前商品id是否存在，如果存在则删除，新增新的记录
             排序
             存储5条最新浏览数据：修剪数据，只保留指定区间内的数据
            
"""

"""
获取用户浏览记录：
    一、前端？ 后端？
        前端：发起ajax请求，get
        后端：获取某个用户的浏览记录
    二、后端逻辑流程
        1.接受数据：暂无
        2.数据校验：暂无
        3.数据处理：获取(查看)用户历史浏览记录
        4.返回响应：json:code,msg,skus:[{"id":1,"name":"xxx","default_image":"xxxx","price":123},{}]
    三、细化
        1.接受数据：暂无
        2.数据校验：暂无
        3.数据处理：获取(查看)用户历史浏览记录
            3.1连接redis（key:list）
            3.2获取数据ids = [2,3,4,5]
            3.3处理数据
                skus = []
                for id in ids:
                    skuinfo = SKU.objects.get(pk=id)
                    skus.append({
                        "id":stuinfo.id,
                        。。。。
                    })
                    
        4.返回响应：json:code,msg,skus:[{"id":1,"name":"xxx","default_image":"xxxx","price":123},{}]
    四、确认
        get  url：
        参数：无
        
"""
from django_redis import get_redis_connection
from django.contrib.auth.mixins import LoginRequiredMixin
class UserHistoryView(LoginJsonRequiredMixin,View):
    def post(self,request):
        # 0 判断用户是否登录
        # if not request.user.is_authenticated:
        #     # 未登录
        #     return JsonResponse({"code":4001,"msg":"未登录"})
        # 1接受参数(ajax)
        sku_id = json.loads(request.body.decode()).get("sku_id")
        # 2数据校验
        try:
            skuinfo = SKU.objects.get(pk=sku_id)
        except Exception as e:
            return JsonResponse({"code":400,"msg":"参数有误"})
        # 3数据处理-将用户的浏览记录保存在redis中，以list方式进行存储
        # 3.1连接redis
        redis_conn = get_redis_connection("history")
        # 3.2存储记录：去重lrem(name, count, value):根据参数 COUNT 的值，移除列表中与参数 VALUE 相等的元素。
        # userid = request.user
        redis_conn.lrem("history_%s" % request.user.id,0,sku_id)
        # 3.3存储记录：新增
        redis_conn.lpush("history_%s" % request.user.id,sku_id)
        # 3.4修剪数据:ltrim让列表只保留指定区间内的元素，不在指定区间之内的元素都将被删除
        redis_conn.ltrim("history_%s" % request.user.id,0,4)
        # 4返回响应
        return JsonResponse({"code":200,"msg":"ok"})

    def get(self,request):
        # 1连接redis
        redis_conn = get_redis_connection("history")
        # 2获取数据
        ids = redis_conn.lrange("history_%s" % request.user.id,0,4)
        # 3循环遍历ids获取每个商品的详细信息
        skus =[]
        for id in ids:
            skuinfo = SKU.objects.get(pk=id)
            skus.append({
                "id":skuinfo.id,
                "name":skuinfo.name,
                "default_image":skuinfo.default_image.url,
                "price":skuinfo.price
            })

        # 4组织数据返回响应
        data = {
            "code":200,
            "msg":"ok",
            "skus":skus
        }
        return JsonResponse(data)







