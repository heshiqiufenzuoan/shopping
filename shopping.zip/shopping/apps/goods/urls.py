from django.urls import path
from .views import *
app_name = '[goods]'
urlpatterns = [
    # 商品列表
    path("list/<int:category_id>/<int:page>/",GoodsListView.as_view(),name="list"),
    # 热销商品
    path("hot/<int:category_id>/", GoodsHotView.as_view(), name="hot"),
    # 商品的详情
    path("detail/<int:sku_id>/",GoodsDetailView.as_view(),name="detail"),
    # 添加用户历史浏览记录
    path("browse_histories/",UserHistoryView.as_view(),name="browse_histories")

]