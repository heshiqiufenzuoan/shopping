
def get_bread(category):
    breadcrumb = {
        "cat1":"",
        "cat2":"",
        "cat3":""
    }
    # 判断当前分类是第几及分类
    # 判断当前分类是否存在上级，不存在则为第一级分类
    if category.parent is None:
        breadcrumb['cat1'] = category.name
    # 判断当前分类是否存在下一级分类:模型外键中的related_name的值是小写_set的别名
    elif category.subs.count()>0:
        breadcrumb['cat1'] = category.parent.name
        breadcrumb['cat2'] = category.name
    else:
        breadcrumb['cat1'] = category.parent.parent.name
        breadcrumb['cat2'] = category.parent.name
        breadcrumb['cat3'] = category.name


    return breadcrumb
