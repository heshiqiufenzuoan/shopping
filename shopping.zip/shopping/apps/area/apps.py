from django.apps import AppConfig


class AreaConfig(AppConfig):
    name = 'area'
