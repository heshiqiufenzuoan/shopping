from django.shortcuts import render

# Create your views here.
from django.views import View
from .models import *
from apps.area.models import *
from django.http import HttpResponse,JsonResponse
"""
省市区							
id	     name	parent_id		
10000	山西省						
10010	太原市	10000					
10011	小店区	10010					
20000	江苏省						
20100	苏州市	20000					
20101	昆山市	20100		
需求：获取所有的省份：select * from areas where parent_id is Null	--不需要上级编号
需求：获取市/区数据：select * from areas where parent_id=xxx	    --需要传参数上级编号

收货地址管理模块：
    1.获取省份数据：ajax请求，需要返回json数据格式的数据 [{},{}]/{}
       areas =  Area.objects.filter(parent_id__isnull=True)	# QuerySet[ob,ob,ob]
       注意：要将获取到的省份数据的查询结果集转为json格式（[{"id":1,"name":"xxx"},{...},...]）
"""
class shendata(View):
    def get(self,request):
        pass
# 1.url:xxxx/erea/10010/
class shiqudata(View):
    def get(self,request,parent_id):
        pass

# 2./url:xxxx/area/?parent_id=10010
class shiqudata(View):
    def get(self,request):
        parent_id = request.GET.get("parent_id")
        pass
# url:xxxx/area/?parent_id=10010

"""
优化：对于一段时间(1小时、一天、一星期、一年。。。)内发生变化的概率较小的数据
     并且有一定的访问量，可以借助于缓存技术，以减少对数据库的访问
"""
from django.core.cache import cache
class AreasView(View):
    def get(self, request, ):
        # 判断是否有传parent_id参数：没传：省份数据；传了：市、区数据
        parent_id = request.GET.get("parent_id")# 没有获取到默认返回None
        if parent_id is None:
            # 判断缓存中是否有数据，有的话直接使用缓存中的数据进行响应
            data = cache.get("province")# None
            if data is not None:
                return JsonResponse(data)
            #获取省份数据
            areas = Area.objects.filter(parent_id__isnull= True)# parent__isnull=True
            # print(areas)
            # 处理数据-序列化：将查询结果集转为json格式（列表[{},{}]）
            """
            {
                "code":200,
                "msg":"ok",
                "province_list":province_list
            }
            """
            province_list = []
            for item in areas:
                pdata = {
                    "id":item.id,
                    "name":item.name
                }
                # 将每个数据字典追加到列表中
                province_list.append(pdata)
            # print(province_list)
            data = {
                "code": 200,
                "msg": "ok",
                "province_list": province_list
            }
            # 将获取到的数据存储在缓存中
            cache.set("province",data,3600*24*7)
            # return JsonResponse(province_list,safe=False)
            return JsonResponse(data)
            # return HttpResponse("ok")
        else:
            # 获取市、区数据
            # 判断缓存中是否有数据，有的话直接使用缓存中的数据进行响应
            data = cache.get("sublist_"+parent_id)  # None
            if data is not None:
                return JsonResponse(data)

            areas = Area.objects.filter(parent_id = parent_id)
            # 处理数据-序列化：将查询结果集转为json格式（列表[{},{}]）
            sub_list = []
            for item in areas:
                pdata = {
                    "id": item.id,
                    "name": item.name
                }
                # 将每个数据字典追加到列表中
                sub_list.append(pdata)
            # print(province_list)
            data = {
                "code": 200,
                "msg": "ok",
                "sub_list": sub_list
            }
            # 将获取到的数据存储在缓存中
            cache.set("sublist_"+parent_id, data, 3600 * 24 * 7)
            # return JsonResponse(sub_list, safe=False)
            return JsonResponse(data)