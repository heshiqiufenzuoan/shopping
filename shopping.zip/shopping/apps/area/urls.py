from django.urls import path
from .views import *
app_name = '[area]'
urlpatterns = [
    # 获取省市区数据
    path("areas/",AreasView.as_view(),name="areas")
]