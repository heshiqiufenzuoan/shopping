from django.urls import path
from .views import *
app_name = '[orders]'
urlpatterns = [
    path("orders/",PlaceOrdersView.as_view(),name="orders"),
    path("commit/",OrdersCommitView.as_view(),name="commit"),
    path("success/",OrderSuccessView.as_view(),name="success")
]