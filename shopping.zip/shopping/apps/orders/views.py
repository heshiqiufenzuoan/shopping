import json
from time import timezone, time
import pytz

from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.views import View

from apps.goods.models import SKU
from apps.users.models import Address
from .models import *
"""
确认订单：购物车界面点击去结算展示确认订单界面
    一、功能需求分析：前端？后端？
        前端：展示了订单确认界面：登录用户的收货地址信息、下单的商品数据、下单商品的数量以及价格的统计
        后端：展示place_order.html  context
             数据：获取登陆者的收货地址信息
                  下单商品信息：从redis数据库中获取被选中的购物车商品的信息
                  下单商品的数量以及价格的统计信息
    二、后端的逻辑分析
        1.接受参数：暂无
        2.校验数据：暂无
        3.处理数据：查看获取数据
            3.1收货地址数据
            3.2下单商品的数据（redis购物车数据中被勾选的商品的数据）
            3.3下单商品的数量以及价格的统计信息
        4.返回响应
            return render(request,"place_order.html",context)
    
    三、细化逻辑        
        1.接受参数：暂无
        2.校验数据：暂无
        3.处理数据：查看获取数据
            3.1收货地址数据
                addresses = Address.objects.filter(user=request.user,is_delete=False)
                addresses = Address.objects.filter(user_id=request.user.id,is_delete=False)

            3.2下单商品的数据（redis购物车数据中被勾选的商品的数据）
                3.2.1连接redis
                3.2.2获取hash中的数据：carts_userid=》{sku_id:count,sku_id:count}=》keys()
                3.2.3获取set中的数据：selected_userid=》{sku_id,sku_id}
                3.2.4处理数据获取被选中的商品id和数量：{sku_id:count}
                3.2.5获取所有被选中的商品的信息
                
            3.3下单商品的数量以及价格的统计信息
        4.返回响应
            context = {
                
            }
            如果前端使用的是模板渲染：{{ name }} {% for  ...%}
                获得的地址或者是商品数据可以直接是queryset对象
            如果前端使用的是vue渲染：[[name]]  v-for=""  数组
                获得的地址或者是商品数据要转为字典或者列表返回
                
            return render(request,"place_order.html",context)
       
    四、get  响应：render()
        url:orders/orders/
        
"""
from django.contrib.auth.mixins import LoginRequiredMixin
from django_redis import get_redis_connection
class PlaceOrdersView(LoginRequiredMixin,View):
    def get(self,request):
        # 1获取登录用户的个人收货地址信息
        addresses = Address.objects.filter(user=request.user, is_deleted=False)
        # 2获取购物车选中商品的信息
        redis_conn = get_redis_connection("carts")
        skuid_count = redis_conn.hgetall("carts_%s"%request.user.id)
        selected = redis_conn.smembers("selected_%s"%request.user.id)
        #处理数据：{sku_id:count}
        orderinfo = {}# 购物车中选中的商品的id和数量
        for sku_id,count in skuid_count.items():
            if sku_id in selected:
                orderinfo[sku_id.decode()] = count.decode()
        # 获取所有被选中的商品的信息/商品数量统计、商品价格统计、运费
        skus = SKU.objects.filter(id__in = orderinfo.keys())
        # print(orderinfo)
        total_count = 0# 订单商品数量
        total_price = 0# 订单商品价格总计
        for sku in skus:
            # 动态添加所需要的属性：数量，小计
            sku.count = orderinfo[str(sku.id)]
            sku.amount = int(sku.price)*int(orderinfo[str(sku.id)])
            total_count += int(orderinfo[str(sku.id)])
            total_price += int(sku.price)*int(orderinfo[str(sku.id)])

        # 组织数据

        data = {
            "addresses":addresses,
            "skus":skus,
            "yunfei":10,
            "total_count":total_count,
            "total_price":total_price
        }
        return render(request,"place_order.html",context=data)

"""
提交订单：
    一、功能需求分析。前端？后端？
        前端：在订单确认页面点击《提交订单》跳转到下单成功界面
            参数：收货地址:address_id/支付方式：pay_methods
            
        后端：数据的持久化存储：mysql*、redis
            将订单信息进行存储：
                订单基本信息表：id  订单编号  下单时间  【商品信息、数量】 小计  收货地址
                一个订单买了2个商品
                订单和商品的关系：一对多  2张表
                
                1  202109271  xxx      6505   address_id  1    2
                1  202109271  xxx      6505   address_id  2    3
                
                1.订单基本信息表
                1  202109271  xxx      6505   address_id   user_id
                
                2.订单详情表：
                编号    商品id    商品数量  订单编号
                1        1        3      1
                2        2        2      1
    二、后端逻辑分析：
        1.接受数据
        2.校验数据
        3.处理数据
        4.返回响应：根据请求渲染下单成功的页面
        
    三、细化逻辑    
        1.接受数据：address_id  pay_methods
        2.校验数据：
            2.1参数是否齐全
            2.2地址是否存在
            2.3支付方式是否有效 pay_methods in [1,2]
        3.处理数据:新增订单信息数据
            3.1订单的基本信息存储
            
            3.2订单商品信息存储
            
            3.3商品信息的库存量和销量要进行编辑
            
            补充：3.4将购物车中完成下单的商品删除
                redis中购物车数据：
                    hash->{sku_id:count,...}：hdel("carts_userid",被选中的商品的id)
                    set->{sku_id,...}：srem("selected_userid",被选中的商品的id)
            
        4.返回响应：json数据（order_id）      
            
    四、确认
        ajax异步请求  post
        url：orders/commit/      
"""
from django.db import transaction
class OrdersCommitView(View):
    def post(self,request):
        # 1接受数据
        data = json.loads(request.body.decode())
        address_id = data.get("address_id")
        pay_method = data.get("pay_method")
        # 2校验数据
        if not all([address_id,pay_method]):
            return JsonResponse({"code":400,"msg":"参数不全"})

        try:
            addr = Address.objects.get(id=address_id)
        except Exception as e:
            return JsonResponse({"code":400,"msg":"参数有误"})

        # if not pay_method in [1,2]:
        if not pay_method in [OrderInfo.PAY_METHODS_ENUM['CASH'], OrderInfo.PAY_METHODS_ENUM['ALIPAY']]:# 提高代码的可读性
            return JsonResponse({"code":400,"msg":"参数有误"})

        # 3数据处理：存储数据
        # 3.1订单的基本信息存储
        from time import strftime,localtime
        order_id = str(strftime("%Y%m%d%H%M%S", localtime())) + str(request.user.id)# 当时时间年月日时分秒用户id：20210927050412

        # 2获取购物车选中商品的信息
        redis_conn = get_redis_connection("carts")
        skuid_count = redis_conn.hgetall("carts_%s" % request.user.id)
        selected = redis_conn.smembers("selected_%s" % request.user.id)
        # 处理数据：{sku_id:count}
        orderinfo = {}  # 购物车中选中的商品的id和数量
        for sku_id, count in skuid_count.items():
            if sku_id in selected:
                orderinfo[sku_id.decode()] = count.decode()
        # 获取所有被选中的商品的信息/商品数量统计、商品价格统计、运费
        skus = SKU.objects.filter(id__in=orderinfo.keys())
        # print(orderinfo)
        total_count = 0  # 订单商品数量
        total_price = 0  # 订单商品价格总计
        for sku in skus:
            # 动态添加所需要的属性：数量，小计
            sku.count = orderinfo[str(sku.id)]
            sku.amount = int(sku.price) * int(orderinfo[str(sku.id)])
            total_count += int(orderinfo[str(sku.id)])
            total_price += int(sku.price) * int(orderinfo[str(sku.id)])

        yunfei = 10
        # 根据支付方式判断订单的状态：提高代码的可读性
        # if pay_method == 1:
        #     status =  2
        # else:
        #     status =  1
        if pay_method == OrderInfo.PAY_METHODS_ENUM["CASH"]:
            status = OrderInfo.ORDER_STATUS_ENUM['UNSEND']
        else:
            status = OrderInfo.ORDER_STATUS_ENUM['UNPAID']

        with transaction.atomic() :# 开启事务操作
            # 设置事务回滚点
            save_id = transaction.savepoint()
            # 将数据存储到orderinfo表中
            order = OrderInfo.objects.create(
                order_id=order_id,
                user = request.user,
                address=addr,
                total_count=total_count,
                total_amount=total_price,
                freight = yunfei,
                pay_method=pay_method,
                status = status
            )

            # 3.2订单商品信息存储:order  sku  count  price
            for sku in skus:
                # 判断商品的库存是否充足
                if int(orderinfo[str(sku.id)]) <= sku.stock:
                    OrderGoods.objects.create(
                        order = order,
                        sku = sku,
                        count = orderinfo[str(sku.id)],
                        price = sku.price
                    )
                    # 使用延时模拟并发下单
                    import time
                    time.sleep(10)

                    # 3.3商品信息的库存量和销量要进行编辑
                    sku.stock -= int(orderinfo[str(sku.id)])
                    sku.sales += int(orderinfo[str(sku.id)])
                    sku.save()

                else:
                    # 事务回滚
                    transaction.savepoint_rollback(save_id)
                    return JsonResponse({"code":400,"msg":"库存不足"})
        # 提交事务
        transaction.savepoint_commit(save_id)

        #补充：3.4将购物车中完成下单的商品删除
        redis_conn.hdel("carts_%s"%request.user.id,*selected)
        redis_conn.srem("selected_%s"%request.user.id,*selected)

        return JsonResponse({"code":200,"msg":"ok","order_id":order_id})


# 下单成功界面显示
class OrderSuccessView(View):
    def get(self,request):
        # 获取数据
        order_id = request.GET.get("order_id")
        payment_amount = request.GET.get("payment_amount")
        pay_method = request.GET.get("pay_method")
        # 组织数据
        data={
            "order_id":order_id,
            "payment_amount":payment_amount,
            "pay_method":pay_method
        }
        return render(request,'order_success.html',context=data)

"""
用户A：
    商品1：2  枷锁：悲观锁
    商品2：4  等待
用户B：
    商品1：3  等待
    商品2：1

死锁
    
"""












