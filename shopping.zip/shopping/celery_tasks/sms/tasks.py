"""
    ① 任务的本质就是函数
    ② 这个函数必须要被celery的实例对象的 task装饰器装饰
    ③ 必须调用celery实例对象的自动检测来检测任务
"""
import json

from ronglian_sms_sdk import SmsSDK

from apps.verifications.views import accId, accToken, appId
from celery_tasks.main import app
# 有异常自动重试三次
# bind：绑定任务，保证task对象会作为第一个参数自动传入给self
# name：异步任务别名
# retry_backoff：异常自动重试的时间间隔 第n次(retry_backoff×2^(n-1))s
# max_retries：异常自动重试次数的上限
# default_retry_delay 重新尝试的间隔时间,默认是180s
@app.task(bind=True,default_retry_delay=10)
def send_sms_code(self,mobile,datas):
    try:
        sdk = SmsSDK(accId, accToken, appId)
        resp = sdk.sendMessage('1', mobile, datas)
    except Exception as e:
        raise self.retry(exc = e,max_retries = 3)
    # resp结果json字符串
    resp = json.loads(resp)
    # 根据返回的状态码判断是否发送成功，发送成功返回的状态码是000000
    if resp.get("statusCode") != '000000':
        raise self.retry(exc="发送失败....", max_retries=3)

    # print(resp.get("statusCode"))
