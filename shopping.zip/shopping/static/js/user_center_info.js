var vm = new Vue({
    el: '#app',
    // 修改Vue变量的读取语法，避免和django模板语法冲突
    delimiters: ['[[', ']]'],
    data: {
        host: host,
        username: username,
        mobile: mobile,
        email: email,
        email_active: email_active,
        set_email: false,
        error_email: false,
        error_email_message: '',
        send_email_btn_disabled: false,
        send_email_tip: '重新发送验证邮件',
        histories: []
    },
    // ES6语法
    mounted() {
        // 额外处理用户数据
        this.email_active = (this.email_active=='True') ? true : false;
        this.set_email = (this.email=='') ? true : false;

        // 请求浏览历史记录
        this.browse_histories();
    },
    methods: {
        // 检查email格式
        check_email(){
            var re = /^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$/;
            if (re.test(this.email)) {
                this.error_email = false;
            } else {
                this.error_email_message = '邮箱格式错误';
                this.error_email = true;
                return;
            }
        },
        // 取消保存
        cancel_email(){
            this.email = '';
            this.error_email = false;
        },
        // 保存email
        save_email(){
            // 检查email格式
            this.check_email();

            if (this.error_email == false) {
                var url = this.host + '/users/emails/';
                axios.put(url, {
                        email: this.email
                    }, {
                        headers: {
                            'X-CSRFToken':getCookie('csrftoken')// 携带csrftoken信息，从cookie中获取
                        },
                        responseType: 'json'
                    })
                    .then(response => {
                        if (response.data.code == 200) {
                            this.set_email = false;
                            this.send_email_btn_disabled = true;
                            this.send_email_tip = '已发送验证邮件';
                        } else if (response.data.code == '4101') {
                            location.href = '/users/login/?next=/info/';// 跳转登录页面
                        } else { // 5000 5001
                            this.error_email_message = response.data.msg;
                            this.error_email = true;
                        }
                    })
                    .catch(error => {
                        console.log(error.response);
                    });
            }
        },
        // 请求浏览历史记录
        browse_histories(){
            var url = this.host + '/goods/browse_histories/';
            axios.get(url, {
                    responseType: 'json'
                })
                .then(response => {
                    this.histories = response.data.skus;
                    for(var i=0; i<this.histories.length; i++){
                        this.histories[i].url = '/goods/detail/' + this.histories[i].id + '/';
                    }
                })
                .catch(error => {
                    console.log(error.response);
                })
        }
    }
});
